package com.example.latihanstorage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

public class InternalActivity extends AppCompatActivity implements View.OnClickListener {

    public static final String FILENAME = "namafile.txt";
    Button btnBuat, btnUbah, btnBaca, btnHapus;
    TextView txtBaca;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_internal);
        btnBuat = findViewById(R.id.btnBuat);
        btnUbah = findViewById(R.id.btnUbah);
        btnBaca = findViewById(R.id.btnBaca);
        btnHapus = findViewById(R.id.btnHapus);
        txtBaca = findViewById(R.id.txtBaca);

        btnBuat.setOnClickListener(this);
        btnUbah.setOnClickListener(this);
        btnBaca.setOnClickListener(this);
        btnHapus.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) { jalankanPerintah(v.getId()); }

    public void jalankanPerintah(int id) {
        switch (id) {
            case R.id.btnBuat:
                BtnBuat();
                break;
            case R.id.btnUbah:
                BtnUbah();
                break;
            case R.id.btnBaca:
                BtnBaca();
                break;
            case R.id.btnHapus:
                BtnHapus();
                break;
        }
    }

    void BtnBuat() {
        String isiFile = "Coba Isi Data File Text";
        File file = new File(getFilesDir(), FILENAME);

        FileOutputStream outputStream = null;
        try {
            file.createNewFile();
            outputStream = new FileOutputStream(file, true);
            outputStream.write(isiFile.getBytes());
            outputStream.flush();
            outputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void BtnUbah() {
        String ubah = "Update isi data file text";
        File file = new File(getFilesDir(), FILENAME);

        FileOutputStream outputStream = null;
        try {
            file.createNewFile();
            outputStream = new FileOutputStream(file, false);
            outputStream.write(ubah.getBytes());
            outputStream.flush();
            outputStream.close();
        } catch (Exception e){
            e.printStackTrace();
        }

    }

    void BtnBaca() {
        File fileInternal = getFilesDir();
        File file = new File(fileInternal, FILENAME);
        if (file.exists()){
            StringBuilder text = new StringBuilder();
            try {
                BufferedReader br = new BufferedReader(new FileReader(file));
                String line = br.readLine();
                while (line != null){
                    text.append(line);
                    line = br.readLine();
                }
                br.close();
            }catch (IOException e){
                System.out.println("Error " + e.getMessage());
            }
            txtBaca.setText(text.toString());
        }
    }

    void BtnHapus() {
        File file = new File(getFilesDir(), FILENAME);
        if (file.exists()) {
            file.delete();
        }
    }
}
